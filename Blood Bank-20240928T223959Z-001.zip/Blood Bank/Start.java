import GUI.*;
public class Start{
	public static void main(String []args){	
		LoginPage lp = new LoginPage();
	}
	
//javac File/FileIO.java && javac Entity/BloodInventory.java && javac Entity/BloodDonor.java && javac Entity/BloodReceiver.java && javac EntityList/ReceiverList.java && javac EntityList/DonorList.java && javac EntityList/InventoryList.java && javac  GUI/InventoryPage.java && javac  GUI/DonorPage.java && javac  GUI/ReceiverPage.java && javac GUI/RegistrationPage.java && javac GUI/HomePage.java && javac GUI/LoginPage.java && javac Start.java && java Start
}